<?php
//THIS LANDING PAGE OKEH 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetAdopt | Welcome!</title>
    <link rel="stylesheet" href="style/landingpage.css">
</head>

<body>

    <header>
        <nav class="navbar">
            <a href="index.php" class="logo">
                🐾 <span>Pet<span>Adopt</span></span>
            </a>

            <div class="nav-links">
                <a href="index.php" class="active">Home</a>
                <a href="#pets">Browse Pets</a>
                <a href="#how-it-works">How It Works</a>
                <a href="login.php">Login</a>
            </div>

            <a href="signup.php" class="nav-button">Join Us ♡</a>
        </nav>
    </header>


    <main>

        <!-- HERO -->
        <section class="hero">

            <div class="hero-content">

                <div class="hero-text">

                    <span class="small-title">🌿 A HOME FOR EVERY PAW</span>

                    <h1>
                        Find a little
                        <span>love to bring</span>
                        home.
                    </h1>

                    <p>
                        Meet adorable pets waiting for their forever family.
                        Your new best friend might be closer than you think.
                    </p>

                    <div class="buttons">
                        <a href="login.php" class="button">Find a Pet ♡</a>
                        <a href="#how-it-works" class="learn">How it works →</a>
                    </div>

                </div>


                <div class="hero-art">

                    <div class="leaf leaf-one">🌿</div>
                    <div class="leaf leaf-two">🍃</div>

                    <div class="pet-circle">
                        <img src="img/ginger.png" alt="ginger">
                    </div>

                    <div class="hello-card">
                        <span>♡</span>
                        <div>
                            <strong>Say hello!</strong>
                            <small>Your new friend is waiting.</small>
                        </div>
                    </div>

                    <div class="paw paw-one">🐾</div>
                    <div class="paw paw-two">🐾</div>

                </div>

            </div>

        </section>


        <!-- HOW IT WORKS -->
        <section class="how" id="how-it-works">

            <div class="heading">
                <span>♡ EASY & HEARTFELT</span>
                <h2>How adoption works</h2>
                <p>Three simple steps to meet your new companion.</p>
            </div>

            <div class="steps">

                <article>
                    <div class="icon green">🔎</div>
                    <b>01 · Browse</b>
                    <p>Look through pets waiting for a loving home.</p>
                </article>

                <article>
                    <div class="icon orange">💌</div>
                    <b>02 · Apply</b>
                    <p>Send an adoption request for your chosen pet.</p>
                </article>

                <article>
                    <div class="icon brown">🏡</div>
                    <b>03 · Welcome Home</b>
                    <p>Bring your new best friend into their forever home.</p>
                </article>

            </div>

        </section>


        <!-- PETS -->
        <section class="pets" id="pets">

            <div class="heading">
                <span>🐾 MEET OUR PETS</span>
                <h2>Waiting for their person</h2>
                <p>Maybe that person could be you.</p>
            </div>

            <div class="pet-list">

                <article class="pet-card">
                    <div class="pet-photo dog">🐶</div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Buddy</h3>
                        <p>Golden Retriever · 2 years</p>
                        <a href="login.php">Meet Buddy →</a>
                    </div>
                </article>


                <article class="pet-card">
                    <div class="pet-photo cat">🐱</div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Luna</h3>
                        <p>Domestic Shorthair · 1 year</p>
                        <a href="login.php">Meet Luna →</a>
                    </div>
                </article>


                <article class="pet-card">
                    <div class="pet-photo puppy">🐕</div>

                    <div class="pet-info">
                        <span class="available">● Available</span>
                        <h3>Milo</h3>
                        <p>Shih Tzu · 3 years</p>
                        <a href="login.php">Meet Milo →</a>
                    </div>
                </article>

            </div>

            <a href="login.php" class="all-pets">See all pets →</a>

        </section>


        <!-- CTA -->
        <section class="cta">

            <div>
                <span>🌱 EVERY PET DESERVES A HOME</span>

                <h2>
                    Maybe your new
                    <em>best friend</em>
                    is waiting.
                </h2>

                <a href="signup.php" class="button orange-button">
                    Start Your Journey ♡
                </a>
            </div>

        </section>

    </main>


    <footer>
        <div>
            <strong>🐾 PetAdopt</strong>
            <p>Helping pets find their forever homes.</p>
        </div>

        <p>© 2026 PetAdopt</p>
    </footer>

</body>

</html>