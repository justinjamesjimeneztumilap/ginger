<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

$species_list = ["Dog", "Cat", "Other"];
$gender_list  = ["Male", "Female"];
$status_list  = ["Available", "Pending", "Adopted"];

$error = "";

// Empty form (used for "Add a pet")
$form = [
    "id"            => 0,
    "name"          => "",
    "species"       => "Dog",
    "breed"         => "",
    "age"           => "",
    "gender"        => "Male",
    "description"   => "",
    "health_status" => "Healthy",
    "status"        => "Available",
];

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action = $_POST['action'] ?? "";

    // Delete a pet
    if ($action == "delete")
    {
        $pet_id = (int)($_POST['id'] ?? 0);

        $stmt = mysqli_prepare($con, "DELETE FROM pets WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $pet_id);
        mysqli_stmt_execute($stmt);

        header("Location: manage_pets.php?deleted=1");
        die;
    }

    // Add or update a pet
    if ($action == "save")
    {
        $form = [
            "id"            => (int)($_POST['id'] ?? 0),
            "name"          => trim($_POST['name'] ?? ""),
            "species"       => $_POST['species'] ?? "",
            "breed"         => trim($_POST['breed'] ?? ""),
            "age"           => trim($_POST['age'] ?? ""),
            "gender"        => $_POST['gender'] ?? "",
            "description"   => trim($_POST['description'] ?? ""),
            "health_status" => trim($_POST['health_status'] ?? ""),
            "status"        => $_POST['status'] ?? "",
        ];

        if ($form['health_status'] === "") { $form['health_status'] = "Healthy"; }

        if ($form['name'] === "" || $form['breed'] === "" || $form['age'] === "")
        {
            $error = "Please fill in the pet's name, breed and age.";
        }
        elseif (strlen($form['name']) > 100 || strlen($form['breed']) > 100 || strlen($form['age']) > 30 || strlen($form['health_status']) > 50)
        {
            $error = "One of the fields is too long. Please shorten it.";
        }
        elseif (!in_array($form['species'], $species_list, true) || !in_array($form['gender'], $gender_list, true) || !in_array($form['status'], $status_list, true))
        {
            $error = "Please choose valid options for species, gender and status.";
        }
        else
        {
            if ($form['id'] > 0)
            {
                $stmt = mysqli_prepare($con, "UPDATE pets SET name = ?, species = ?, breed = ?, age = ?, gender = ?, description = ?, health_status = ?, status = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "ssssssssi", $form['name'], $form['species'], $form['breed'], $form['age'], $form['gender'], $form['description'], $form['health_status'], $form['status'], $form['id']);
                mysqli_stmt_execute($stmt);

                header("Location: manage_pets.php?saved=updated");
            }
            else
            {
                $stmt = mysqli_prepare($con, "INSERT INTO pets (name, species, breed, age, gender, description, health_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "ssssssss", $form['name'], $form['species'], $form['breed'], $form['age'], $form['gender'], $form['description'], $form['health_status'], $form['status']);
                mysqli_stmt_execute($stmt);

                header("Location: manage_pets.php?saved=added");
            }

            die;
        }
    }
}
elseif (isset($_GET['edit']))
{
    // Load a pet into the form for editing
    $edit_id = (int)$_GET['edit'];

    $stmt = mysqli_prepare($con, "SELECT * FROM pets WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $edit_id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row)
    {
        $form = $row;
        $form['description'] = $row['description'] ?? "";
    }
}

$editing = $form['id'] > 0;

$pets = mysqli_query($con, "SELECT id, name, species, breed, age, gender, status FROM pets ORDER BY id DESC");

$page_kicker = "MANAGE PETS";
$page_title  = "Pets at the shelter 🐾";
$page_text   = "Add new pets and keep their details up to date.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Manage Pets</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "pets"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['saved'])): ?>
            <p class="alert alert-success" role="status">Pet <?php echo $_GET['saved'] == "added" ? "added" : "updated"; ?>.</p>
        <?php elseif (isset($_GET['deleted'])): ?>
            <p class="alert alert-success" role="status">Pet deleted.</p>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <p class="alert alert-error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <!-- ADD / EDIT FORM -->
        <form method="post" class="form-card pet-form" id="pet-form">

            <h2><?php echo $editing ? "Edit " . htmlspecialchars($form['name']) : "Add a new pet"; ?></h2>

            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?php echo (int)$form['id']; ?>">

            <div class="form-grid">

                <div>
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" maxlength="100" value="<?php echo htmlspecialchars($form['name']); ?>" required>
                </div>

                <div>
                    <label for="species">Species</label>
                    <select id="species" name="species">
                        <?php foreach ($species_list as $s): ?>
                            <option value="<?php echo $s; ?>" <?php echo $form['species'] == $s ? "selected" : ""; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="breed">Breed</label>
                    <input type="text" id="breed" name="breed" maxlength="100" value="<?php echo htmlspecialchars($form['breed']); ?>" required>
                </div>

                <div>
                    <label for="age">Age</label>
                    <input type="text" id="age" name="age" maxlength="30" placeholder="e.g. 2 years" value="<?php echo htmlspecialchars($form['age']); ?>" required>
                </div>

                <div>
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender">
                        <?php foreach ($gender_list as $g): ?>
                            <option value="<?php echo $g; ?>" <?php echo $form['gender'] == $g ? "selected" : ""; ?>><?php echo $g; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <?php foreach ($status_list as $st): ?>
                            <option value="<?php echo $st; ?>" <?php echo $form['status'] == $st ? "selected" : ""; ?>><?php echo $st; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="full">
                    <label for="health_status">Health</label>
                    <input type="text" id="health_status" name="health_status" maxlength="50" value="<?php echo htmlspecialchars($form['health_status']); ?>">
                </div>

                <div class="full">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($form['description']); ?></textarea>
                </div>

            </div>

            <div class="actions">
                <button type="submit" class="btn"><?php echo $editing ? "Save changes" : "Add pet"; ?></button>

                <?php if ($editing): ?>
                    <a href="manage_pets.php" class="btn btn-soft">Cancel</a>
                <?php endif; ?>
            </div>

        </form>


        <!-- PET LIST -->
        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span>🐾 ALL PETS</span>
                    <h2>Pet list</h2>
                </div>
            </div>

            <?php if ($pets && mysqli_num_rows($pets) > 0): ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Pet</th>
                                <th>Breed</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($p = mysqli_fetch_assoc($pets)): ?>
                                <?php list($cls, $emoji) = pet_look($p['species']); ?>
                                <tr>
                                    <td>
                                        <div class="cell-pet">
                                            <span class="cell-emoji <?php echo $cls; ?>"><?php echo $emoji; ?></span>
                                            <?php echo htmlspecialchars($p['name']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($p['breed']); ?></td>
                                    <td><?php echo htmlspecialchars($p['age']); ?></td>
                                    <td><?php echo htmlspecialchars($p['gender']); ?></td>
                                    <td><span class="badge <?php echo strtolower($p['status']); ?>"><?php echo htmlspecialchars($p['status']); ?></span></td>
                                    <td>
                                        <div class="actions">
                                            <a href="manage_pets.php?edit=<?php echo (int)$p['id']; ?>#pet-form" class="btn btn-soft btn-sm">Edit</a>

                                            <form method="post" onsubmit="return confirm('Delete <?php echo htmlspecialchars(addslashes($p['name']), ENT_QUOTES); ?>? Their adoption requests will be deleted too.');">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>

                <div class="empty-state">
                    <div>🐾</div>
                    <h3>No pets yet</h3>
                    <p>Use the form above to add your first pet.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

</body>
</html>
