<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

$users = mysqli_query($con, "SELECT u.user_name, u.email, u.user_type, u.date,
                                    (SELECT COUNT(*) FROM adoption_requests r WHERE r.user_id = u.user_id) AS request_count
                             FROM users u
                             ORDER BY u.date DESC");

$page_kicker = "USERS";
$page_title  = "Registered accounts 👥";
$page_text   = "Everyone who has an account on PetAdopt.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Users</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "users"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined</th>
                        <th>Requests</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($u = mysqli_fetch_assoc($users)): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($u['user_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td><span class="badge <?php echo $u['user_type'] == "Admin" ? "adopted" : "available"; ?>"><?php echo htmlspecialchars($u['user_type']); ?></span></td>
                            <td><?php echo date("M j, Y", strtotime($u['date'])); ?></td>
                            <td><?php echo (int)$u['request_count']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

    </main>

</div>

</body>
</html>
