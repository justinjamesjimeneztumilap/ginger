<?php
// Shared admin sidebar. Set $active before including (dashboard, pets, requests, users)
$active = $active ?? "";

$links = [
    "dashboard" => ["admin_dashboard.php",  "🏠", "Dashboard"],
    "pets"      => ["manage_pets.php",      "🐾", "Manage Pets"],
    "requests"  => ["manage_requests.php",  "💌", "Requests"],
    "users"     => ["manage_users.php",     "👥", "Users"],
];
?>
<aside class="sidebar">

    <a href="admin_dashboard.php" class="logo">
        🐾 Pet<span>Adopt</span>
    </a>

    <nav>
        <?php foreach ($links as $key => $link): ?>
            <a href="<?php echo $link[0]; ?>"<?php echo ($key === $active) ? ' class="active"' : ''; ?>>
                <?php echo $link[1]; ?> <span><?php echo $link[2]; ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <a href="../logout.php" class="logout">
        🚪 <span>Logout</span>
    </a>

</aside>
