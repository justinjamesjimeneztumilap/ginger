<?php
// Shared admin top bar. Set $page_kicker, $page_title, $page_text (already escaped) before including.
?>
<header class="topbar">

    <div>
        <p class="small-title"><?php echo $page_kicker; ?></p>
        <h1><?php echo $page_title; ?></h1>
        <p class="welcome-text"><?php echo $page_text; ?></p>
    </div>

    <div class="profile">
        <div class="profile-icon">🛡️</div>

        <div>
            <strong><?php echo $user_name; ?></strong>
            <small>Admin</small>
        </div>
    </div>

</header>
