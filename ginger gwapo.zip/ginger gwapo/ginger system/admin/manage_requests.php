<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

// Approve or reject a request
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action     = $_POST['action'] ?? "";
    $request_id = (int)($_POST['request_id'] ?? 0);

    if (in_array($action, ["approve", "reject"], true))
    {
        $new_status = ($action == "approve") ? "Approved" : "Rejected";
        $pet_status = ($action == "approve") ? "Adopted"  : "Available";

        mysqli_begin_transaction($con);

        $stmt = mysqli_prepare($con, "SELECT pet_id FROM adoption_requests WHERE id = ? AND status = 'Pending' LIMIT 1");
        mysqli_stmt_bind_param($stmt, "i", $request_id);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($row)
        {
            $stmt = mysqli_prepare($con, "UPDATE adoption_requests SET status = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $new_status, $request_id);
            mysqli_stmt_execute($stmt);

            $stmt = mysqli_prepare($con, "UPDATE pets SET status = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $pet_status, $row['pet_id']);
            mysqli_stmt_execute($stmt);

            mysqli_commit($con);
            header("Location: manage_requests.php?done=" . $action);
            die;
        }

        mysqli_rollback($con);
    }

    header("Location: manage_requests.php");
    die;
}

// Filter tabs
$filter = $_GET['status'] ?? "";
if (!in_array($filter, ["Pending", "Approved", "Rejected"], true)) { $filter = ""; }

$sql = "SELECT r.id, r.message, r.status, r.created_at,
               u.user_name, p.name AS pet_name, p.species
        FROM adoption_requests r
        JOIN pets p ON p.id = r.pet_id
        LEFT JOIN users u ON u.user_id = r.user_id";

if ($filter !== "") { $sql .= " WHERE r.status = ?"; }

$sql .= " ORDER BY (r.status = 'Pending') DESC, r.created_at DESC";

$stmt = mysqli_prepare($con, $sql);
if ($filter !== "") { mysqli_stmt_bind_param($stmt, "s", $filter); }
mysqli_stmt_execute($stmt);
$requests = mysqli_stmt_get_result($stmt);

$page_kicker = "ADOPTION REQUESTS";
$page_title  = "Review requests 💌";
$page_text   = "Approve or reject adoption requests from adopters.";

$tabs = ["" => "All", "Pending" => "Pending", "Approved" => "Approved", "Rejected" => "Rejected"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Requests</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "requests"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['done'])): ?>
            <p class="alert alert-success" role="status">Request <?php echo $_GET['done'] == "approve" ? "approved" : "rejected"; ?>.</p>
        <?php endif; ?>

        <nav class="tabs" aria-label="Filter requests">
            <?php foreach ($tabs as $value => $label): ?>
                <a href="manage_requests.php<?php echo $value !== "" ? "?status=" . $value : ""; ?>"
                   class="tab<?php echo $filter === $value ? " active" : ""; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </nav>

        <?php if ($requests && mysqli_num_rows($requests) > 0): ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Pet</th>
                            <th>Adopter</th>
                            <th>Message</th>
                            <th>Sent</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                            <?php list($cls, $emoji) = pet_look($r['species']); ?>
                            <tr>
                                <td>
                                    <div class="cell-pet">
                                        <span class="cell-emoji <?php echo $cls; ?>"><?php echo $emoji; ?></span>
                                        <?php echo htmlspecialchars($r['pet_name']); ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?></td>
                                <td class="cell-message"><?php echo $r['message'] !== null && $r['message'] !== "" ? htmlspecialchars($r['message']) : "<span class='muted'>No message</span>"; ?></td>
                                <td><?php echo date("M j, Y", strtotime($r['created_at'])); ?></td>
                                <td><span class="badge <?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span></td>
                                <td>
                                    <?php if ($r['status'] == "Pending"): ?>
                                        <div class="actions">
                                            <form method="post">
                                                <input type="hidden" name="action" value="approve">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                                <button type="submit" class="btn btn-sm">Approve</button>
                                            </form>

                                            <form method="post" onsubmit="return confirm('Reject this request?');">
                                                <input type="hidden" name="action" value="reject">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$r['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <div class="empty-state">
                <div>💌</div>
                <h3>No requests here</h3>
                <p>Requests from adopters will show up in this list.</p>
            </div>

        <?php endif; ?>

    </main>

</div>

</body>
</html>
