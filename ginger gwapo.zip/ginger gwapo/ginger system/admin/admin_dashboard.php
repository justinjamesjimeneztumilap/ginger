<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Admin");
$user_name = htmlspecialchars($user_data['user_name']);

function admin_count($con, $sql)
{
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_row($result);
    return (int)$row[0];
}

$total_pets      = admin_count($con, "SELECT COUNT(*) FROM pets");
$available_pets  = admin_count($con, "SELECT COUNT(*) FROM pets WHERE status = 'Available'");
$pending_reqs    = admin_count($con, "SELECT COUNT(*) FROM adoption_requests WHERE status = 'Pending'");
$adopted_pets    = admin_count($con, "SELECT COUNT(*) FROM pets WHERE status = 'Adopted'");
$total_adopters  = admin_count($con, "SELECT COUNT(*) FROM users WHERE user_type = 'Adopter'");

// Latest requests waiting for a decision
$pending = mysqli_query($con, "SELECT r.id, r.created_at, u.user_name, p.name AS pet_name, p.species
                               FROM adoption_requests r
                               JOIN pets p ON p.id = r.pet_id
                               LEFT JOIN users u ON u.user_id = r.user_id
                               WHERE r.status = 'Pending'
                               ORDER BY r.created_at DESC
                               LIMIT 5");

$page_kicker = "PETADOPT ADMIN";
$page_title  = "Welcome back, " . $user_name . "! 🛡️";
$page_text   = "Here's what is happening at the shelter today.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Admin Dashboard</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
    <link rel="stylesheet" href="../style/admin_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "dashboard"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <section class="summary four">

            <article class="summary-card green-card">
                <div class="summary-icon">🐾</div>
                <div>
                    <p>Total Pets</p>
                    <h2><?php echo $total_pets; ?></h2>
                    <small><?php echo $available_pets; ?> available</small>
                </div>
            </article>

            <article class="summary-card orange-card">
                <div class="summary-icon">💌</div>
                <div>
                    <p>Pending Requests</p>
                    <h2><?php echo $pending_reqs; ?></h2>
                    <small>Waiting for you</small>
                </div>
            </article>

            <article class="summary-card brown-card">
                <div class="summary-icon">🏡</div>
                <div>
                    <p>Adopted Pets</p>
                    <h2><?php echo $adopted_pets; ?></h2>
                    <small>In forever homes</small>
                </div>
            </article>

            <article class="summary-card green-card">
                <div class="summary-icon">👥</div>
                <div>
                    <p>Adopters</p>
                    <h2><?php echo $total_adopters; ?></h2>
                    <small>Registered accounts</small>
                </div>
            </article>

        </section>


        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span>💌 NEEDS A DECISION</span>
                    <h2>Latest pending requests</h2>
                </div>

                <a href="manage_requests.php?status=Pending">See all →</a>
            </div>

            <?php if ($pending && mysqli_num_rows($pending) > 0): ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Pet</th>
                                <th>Adopter</th>
                                <th>Sent</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = mysqli_fetch_assoc($pending)): ?>
                                <?php list($cls, $emoji) = pet_look($r['species']); ?>
                                <tr>
                                    <td>
                                        <div class="cell-pet">
                                            <span class="cell-emoji <?php echo $cls; ?>"><?php echo $emoji; ?></span>
                                            <?php echo htmlspecialchars($r['pet_name']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($r['user_name'] ?? "Unknown user"); ?></td>
                                    <td><?php echo date("M j, Y", strtotime($r['created_at'])); ?></td>
                                    <td><a href="manage_requests.php?status=Pending" class="btn btn-sm">Review</a></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>

            <?php else: ?>

                <div class="empty-state">
                    <div>🎉</div>
                    <h3>All caught up</h3>
                    <p>There are no requests waiting for a decision.</p>
                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

</body>
</html>
