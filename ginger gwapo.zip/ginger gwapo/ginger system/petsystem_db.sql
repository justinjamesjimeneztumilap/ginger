-- PetAdopt database (updated)
-- Keeps your existing `users` table + accounts, and adds `pets` and `adoption_requests`.
-- Import in phpMyAdmin: select/create `petsystem_db`, then Import this file.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `petsystem_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `petsystem_db`;

-- --------------------------------------------------------
-- users (unchanged)
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `security_question` varchar(100) NOT NULL,
  `security_answer` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_type` enum('Admin','Adopter') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_name` (`user_name`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO `users` (`id`, `user_id`, `user_name`, `email`, `password`, `security_question`, `security_answer`, `date`, `user_type`) VALUES
(1, 707590562987, 'Admin', 'admin@petadopt.com', '$2y$10$5o9X7eeww6A3/nHSUGBHQOuPHMdMv7HA18KesoJsKNq.5CxZhJADi', 'What is your favorite color?', 'blue', '2026-10-01 13:29:33', 'Admin'),
(2, 7699410573718581, 'Justin', 'Justin@gmail.com', '$2y$10$iR70NgWI10JGL12vBVDdpuWn./QK/8tJwhrPCN1J.2Az6DmIWC5cy', 'What is your favorite color?', 'black', '2026-10-01 14:18:51', 'Adopter');

-- --------------------------------------------------------
-- pets
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `pets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `species` enum('Dog','Cat','Other') NOT NULL DEFAULT 'Dog',
  `breed` varchar(100) NOT NULL,
  `age` varchar(30) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `description` text DEFAULT NULL,
  `health_status` varchar(50) NOT NULL DEFAULT 'Healthy',
  `status` enum('Available','Pending','Adopted') NOT NULL DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pets` (`id`, `name`, `species`, `breed`, `age`, `gender`, `description`, `status`) VALUES
(1, 'Buddy', 'Dog', 'Golden Retriever', '2 years', 'Male', 'Friendly, loves fetch and long walks.', 'Pending'),
(2, 'Luna', 'Cat', 'Domestic Shorthair', '1 year', 'Female', 'Calm and cuddly, great with kids.', 'Available'),
(3, 'Milo', 'Dog', 'Shih Tzu', '3 years', 'Male', 'Gentle lap dog who enjoys quiet evenings.', 'Available'),
(4, 'Bella', 'Dog', 'Labrador Mix', '4 years', 'Female', 'Playful, house-trained and good with other dogs.', 'Available'),
(5, 'Oliver', 'Cat', 'Orange Tabby', '2 years', 'Male', 'Curious explorer who loves window seats.', 'Available'),
(6, 'Coco', 'Dog', 'Beagle', '1 year', 'Female', 'Energetic and sweet, needs an active family.', 'Available');

-- --------------------------------------------------------
-- adoption_requests
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `adoption_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `pet_id` (`pet_id`),
  CONSTRAINT `fk_request_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample: Justin has one pending request for Buddy
INSERT INTO `adoption_requests` (`user_id`, `pet_id`, `message`, `status`) VALUES
(7699410573718581, 1, 'I have a big yard and would love to give Buddy a home.', 'Pending');

COMMIT;
