-- Resets the Admin account password to:  Admin@123
-- Run in phpMyAdmin: select petsystem_db > SQL tab > paste > Go.
-- Then log in with username Admin and password Admin@123, and change it from your account later.

UPDATE `users`
SET `password` = '$2y$10$hbOT1/IRzRjYDMVk8lzN2u4oC/iaZjtFfvt6kBPCoS8cEBDS3BLpK'
WHERE `user_name` = 'Admin';
