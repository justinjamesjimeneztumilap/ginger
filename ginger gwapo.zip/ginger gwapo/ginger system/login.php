<?php
session_start();

include("connection.php");
include("functions.php");

// Already logged in? Send them straight to their dashboard.
if (isset($_SESSION['user_id'], $_SESSION['user_type']))
{
    header("Location: " . ($_SESSION['user_type'] == "Admin" ? "admin/admin_dashboard.php" : "customer/dashboard.php"));
    die;
}

$error = "";
$user_name = "";

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $user_name = trim($_POST['user_name'] ?? "");
    $password  = $_POST['password'] ?? "";

    if ($user_name !== "" && $password !== "")
    {
        // Prepared statement: safe from SQL injection
        $stmt = mysqli_prepare($con, "SELECT user_id, password, user_type FROM users WHERE user_name = ? OR email = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "ss", $user_name, $user_name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user_data = $result ? mysqli_fetch_assoc($result) : null;

        if ($user_data && password_verify($password, $user_data['password']))
        {
            session_regenerate_id(true);

            $_SESSION['user_id']   = $user_data['user_id'];
            $_SESSION['user_type'] = $user_data['user_type'];

            if ($user_data['user_type'] == "Admin")
            {
                header("Location: admin/admin_dashboard.php");
            }
            else
            {
                header("Location: customer/dashboard.php");
            }

            die;
        }

        $error = "Wrong username or password. Please try again.";
    }
    else
    {
        $error = "Please enter your username (or email) and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetAdopt | Login</title>
    <link rel="stylesheet" href="style/login.css">
</head>

<body>

    <header>
        <a href="index.php" class="logo">
            🐾 Pet<span>Adopt</span>
        </a>

        <a href="index.php" class="home-link">
            ← Back to Home
        </a>
    </header>

    <main>

        <section class="login-card">

            <div class="card-icon">🐾</div>

            <p class="small-title">WELCOME BACK</p>

            <h1>Find your way<br>back to <span>PetAdopt.</span></h1>

            <p class="description">
                Log in to browse pets and continue your adoption journey.
            </p>

            <?php if (isset($_GET['reset'])): ?>
                <p class="success-message" role="status">Password updated. You can log in now.</p>
            <?php endif; ?>

            <?php if ($error !== ""): ?>
                <p class="error-message" role="alert"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>

            <form method="post">

                <label for="user_name">Username or email</label>
                <input
                    type="text"
                    id="user_name"
                    name="user_name"
                    placeholder="Enter your username or email"
                    value="<?php echo htmlspecialchars($user_name); ?>"
                    required
                >

                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >

                <a href="forgot_password.php" class="forgot-link">Forgot password?</a>

                <button type="submit">
                    Login <span>→</span>
                </button>

                <p class="account-text">
                    Don't have an account?
                    <a href="signup.php">Create one</a>
                </p>

            </form>

        </section>

        <div class="decoration paw-one">🐾</div>
        <div class="decoration leaf-one">🌿</div>

    </main>

</body>
</html>
