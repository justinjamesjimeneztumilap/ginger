<?php
session_start();

include("connection.php");
include("functions.php");

$error    = "";
$user_name = "";
$question = "";
$step     = 1;   // 1 = enter username, 2 = answer security question + new password

const MAX_ATTEMPTS = 5;

// Look up a user's security details by user_id
function find_user_by_id($con, $user_id)
{
    $stmt = mysqli_prepare($con, "SELECT user_id, user_name, security_question, security_answer FROM users WHERE user_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $user_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

// Starting over
if (isset($_GET['restart']))
{
    unset($_SESSION['reset_user_id'], $_SESSION['reset_attempts']);
    header("Location: forgot_password.php");
    die;
}

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action = $_POST['action'] ?? "";

    // STEP 1: find the account
    if ($action == "find")
    {
        $user_name = trim($_POST['user_name'] ?? "");

        if ($user_name === "")
        {
            $error = "Please enter your username or email.";
        }
        else
        {
            $stmt = mysqli_prepare($con, "SELECT user_id FROM users WHERE user_name = ? OR email = ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, "ss", $user_name, $user_name);
            mysqli_stmt_execute($stmt);
            $found = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

            if ($found)
            {
                $_SESSION['reset_user_id']  = $found['user_id'];
                $_SESSION['reset_attempts'] = 0;
            }
            else
            {
                $error = "We couldn't find an account with that username or email.";
            }
        }
    }

    // STEP 2: check the security answer and set a new password
    if ($action == "reset" && isset($_SESSION['reset_user_id']))
    {
        $account = find_user_by_id($con, $_SESSION['reset_user_id']);

        $answer  = strtolower(trim($_POST['security_answer'] ?? ""));
        $new     = $_POST['new_password'] ?? "";
        $confirm = $_POST['confirm_password'] ?? "";

        if (!$account)
        {
            unset($_SESSION['reset_user_id'], $_SESSION['reset_attempts']);
            $error = "Something went wrong. Please start again.";
        }
        elseif (!hash_equals(strtolower(trim($account['security_answer'])), $answer))
        {
            $_SESSION['reset_attempts']++;

            if ($_SESSION['reset_attempts'] >= MAX_ATTEMPTS)
            {
                unset($_SESSION['reset_user_id'], $_SESSION['reset_attempts']);
                $error = "Too many wrong answers. Please start again.";
            }
            else
            {
                $error = "That answer doesn't match. Please try again.";
            }
        }
        elseif (strlen($new) < 6)
        {
            $error = "Your new password must be at least 6 characters.";
        }
        elseif ($new !== $confirm)
        {
            $error = "The new passwords don't match.";
        }
        else
        {
            $hash = password_hash($new, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($con, "UPDATE users SET password = ? WHERE user_id = ?");
            mysqli_stmt_bind_param($stmt, "ss", $hash, $account['user_id']);
            mysqli_stmt_execute($stmt);

            unset($_SESSION['reset_user_id'], $_SESSION['reset_attempts']);

            header("Location: login.php?reset=1");
            die;
        }
    }
}

// Decide which step to show
if (isset($_SESSION['reset_user_id']))
{
    $account = find_user_by_id($con, $_SESSION['reset_user_id']);

    if ($account)
    {
        $step     = 2;
        $user_name = $account['user_name'];
        $question = $account['security_question'];
    }
    else
    {
        unset($_SESSION['reset_user_id'], $_SESSION['reset_attempts']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetAdopt | Forgot Password</title>
    <link rel="stylesheet" href="style/login.css">
</head>

<body>

    <header>
        <a href="index.php" class="logo">
            🐾 Pet<span>Adopt</span>
        </a>

        <a href="login.php" class="home-link">
            ← Back to Login
        </a>
    </header>

    <main>

        <section class="login-card">

            <div class="card-icon">🔑</div>

            <p class="small-title">FORGOT PASSWORD</p>

            <?php if ($step == 1): ?>

                <h1>Let's get you <span>back in.</span></h1>

                <p class="description">
                    Enter your username or email and we'll ask your security question.
                </p>

            <?php else: ?>

                <h1>Answer to <span>reset.</span></h1>

                <p class="description">
                    Answer your security question, then choose a new password.
                </p>

            <?php endif; ?>

            <?php if ($error !== ""): ?>
                <p class="error-message" role="alert"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>

            <?php if ($step == 1): ?>

                <form method="post">

                    <input type="hidden" name="action" value="find">

                    <label for="user_name">Username or email</label>
                    <input
                        type="text"
                        id="user_name"
                        name="user_name"
                        placeholder="Enter your username or email"
                        value="<?php echo htmlspecialchars($user_name); ?>"
                        required
                    >

                    <button type="submit">
                        Continue <span>→</span>
                    </button>

                    <p class="account-text">
                        Remembered it?
                        <a href="login.php">Back to login</a>
                    </p>

                </form>

            <?php else: ?>

                <form method="post">

                    <input type="hidden" name="action" value="reset">

                    <p class="security-question">
                        <small>Security question for <?php echo htmlspecialchars($user_name); ?></small>
                        <?php echo htmlspecialchars($question); ?>
                    </p>

                    <label for="security_answer">Your answer</label>
                    <input
                        type="text"
                        id="security_answer"
                        name="security_answer"
                        placeholder="Enter your answer"
                        autocomplete="off"
                        required
                    >

                    <label for="new_password">New password</label>
                    <input
                        type="password"
                        id="new_password"
                        name="new_password"
                        placeholder="At least 6 characters"
                        minlength="6"
                        required
                    >

                    <label for="confirm_password">Confirm new password</label>
                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        placeholder="Type it again"
                        minlength="6"
                        required
                    >

                    <button type="submit">
                        Reset password <span>→</span>
                    </button>

                    <p class="account-text">
                        Not your account?
                        <a href="forgot_password.php?restart=1">Start over</a>
                    </p>

                </form>

            <?php endif; ?>

        </section>

        <div class="decoration paw-one">🐾</div>
        <div class="decoration leaf-one">🌿</div>

    </main>

</body>
</html>
