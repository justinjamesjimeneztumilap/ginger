<?php
// Shared sidebar. Set $active before including (dashboard, browse, requests, pets, profile)
$active = $active ?? "";

$links = [
    "dashboard" => ["dashboard.php",   "🏠", "Dashboard"],
    "browse"    => ["browse_pets.php", "🐾", "Browse Pets"],
    "requests"  => ["my_requests.php", "📋", "My Requests"],
    "pets"      => ["my_pets.php",     "🏡", "My Pets"],
    "profile"   => ["profile.php",     "👤", "Profile"],
];
?>
<aside class="sidebar">

    <a href="dashboard.php" class="logo">
        🐾 Pet<span>Adopt</span>
    </a>

    <nav>
        <?php foreach ($links as $key => $link): ?>
            <a href="<?php echo $link[0]; ?>"<?php echo ($key === $active) ? ' class="active"' : ''; ?>>
                <?php echo $link[1]; ?> <span><?php echo $link[2]; ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <a href="../logout.php" class="logout">
        🚪 <span>Logout</span>
    </a>

</aside>
