<?php
session_start();

include("../connection.php");
include("../functions.php");

// Only logged-in adopters can see this page
$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

// Small helper: run a COUNT query with optional user id
function count_rows($con, $sql, $uid = null)
{
    $stmt = mysqli_prepare($con, $sql);
    if ($uid !== null) { mysqli_stmt_bind_param($stmt, "s", $uid); }
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_row(mysqli_stmt_get_result($stmt));
    return (int)$row[0];
}

$available_pets = count_rows($con, "SELECT COUNT(*) FROM pets WHERE status = 'Available'");
$my_requests    = count_rows($con, "SELECT COUNT(*) FROM adoption_requests WHERE user_id = ?", $uid);
$my_adopted     = count_rows($con, "SELECT COUNT(*) FROM adoption_requests WHERE user_id = ? AND status = 'Approved'", $uid);

// 3 newest available pets
$pets = mysqli_query($con, "SELECT id, name, species, breed, age FROM pets WHERE status = 'Available' ORDER BY created_at DESC, id DESC LIMIT 3");

// Most recently adopted pet (approved request)
$stmt = mysqli_prepare($con, "SELECT p.id, p.name, p.species, p.breed, p.age, p.health_status, r.updated_at
                              FROM adoption_requests r JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ? AND r.status = 'Approved'
                              ORDER BY r.updated_at DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$my_pet = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Journey progress
$step_submit   = $my_requests > 0;
$step_approved = $my_adopted > 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Dashboard</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <!-- SIDEBAR -->
    <?php $active = "dashboard"; include("sidebar.php"); ?>


    <!-- MAIN CONTENT -->
    <main class="main-content">

        <!-- TOP BAR -->
        <header class="topbar">

            <div>
                <p class="small-title">PETADOPT DASHBOARD</p>
                <h1>Welcome back, <?php echo $user_name; ?>! 🌿</h1>
                <p class="welcome-text">
                    Find your new best friend today.
                </p>
            </div>

            <div class="profile">
                <div class="profile-icon">🐾</div>

                <div>
                    <strong><?php echo $user_name; ?></strong>
                    <small>Adopter</small>
                </div>
            </div>

        </header>


        <!-- SUMMARY CARDS -->
        <section class="summary">

            <article class="summary-card green-card">
                <div class="summary-icon">🐾</div>

                <div>
                    <p>Available Pets</p>
                    <h2><?php echo $available_pets; ?></h2>
                </div>
            </article>


            <article class="summary-card orange-card">
                <div class="summary-icon">💌</div>

                <div>
                    <p>My Requests</p>
                    <h2><?php echo $my_requests; ?></h2>
                </div>
            </article>


            <article class="summary-card brown-card">
                <div class="summary-icon">🏡</div>

                <div>
                    <p>My Adopted Pets</p>
                    <h2><?php echo $my_adopted; ?></h2>
                </div>
            </article>

        </section>


        <!-- AVAILABLE PETS -->
        <section class="pets-section">

            <div class="section-heading">
                <div>
                    <span>🐾 MEET THE PETS</span>
                    <h2>Pets waiting for a home</h2>
                </div>

                <a href="browse_pets.php">See all →</a>
            </div>


            <div class="pet-list">

                <?php if ($pets && mysqli_num_rows($pets) > 0): ?>
                    <?php while ($pet = mysqli_fetch_assoc($pets)): ?>
                        <?php list($cls, $emoji) = pet_look($pet['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

                            <div class="pet-info">

                                <span class="available">
                                    ● Available
                                </span>

                                <h3><?php echo htmlspecialchars($pet['name']); ?></h3>

                                <p>
                                    <?php echo htmlspecialchars($pet['breed']); ?> · <?php echo htmlspecialchars($pet['age']); ?>
                                </p>

                                <a href="pet_details.php?id=<?php echo (int)$pet['id']; ?>">
                                    View Pet →
                                </a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="welcome-text">No pets are available right now. Please check back soon.</p>
                <?php endif; ?>

            </div>

        </section>


        <!-- ADOPTION JOURNEY -->
        <section class="journey">

            <div class="journey-heading">
                <span>🌱 YOUR ADOPTION JOURNEY</span>

                <h2>Every step brings you closer.</h2>
            </div>

            <div class="steps">

                <div class="step completed">
                    <div>✓</div>
                    <p>Browse Pets</p>
                </div>

                <span class="line"></span>

                <div class="step <?php echo $step_submit ? 'completed' : ''; ?>">
                    <div><?php echo $step_submit ? '✓' : '2'; ?></div>
                    <p>Submit Request</p>
                </div>

                <span class="line"></span>

                <div class="step <?php echo $step_approved ? 'completed' : ''; ?>">
                    <div><?php echo $step_approved ? '✓' : '3'; ?></div>
                    <p>Approval</p>
                </div>

                <span class="line"></span>

                <div class="step <?php echo $step_approved ? 'completed' : ''; ?>">
                    <div><?php echo $step_approved ? '✓' : '4'; ?></div>
                    <p>Welcome Home</p>
                </div>

            </div>

        </section>


        <!-- PET TRACKER -->
        <section class="tracker">

            <?php if ($my_pet): ?>
                <?php list($cls, $emoji) = pet_look($my_pet['species']); ?>

                <div class="tracker-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

                <div class="tracker-info">

                    <span>🏡 YOUR PET</span>

                    <h2><?php echo htmlspecialchars($my_pet['name']); ?></h2>

                    <p><?php echo htmlspecialchars($my_pet['breed']); ?> · <?php echo htmlspecialchars($my_pet['age']); ?> old</p>

                    <div class="tracker-details">

                        <div>
                            <small>Health</small>
                            <strong><?php echo htmlspecialchars($my_pet['health_status']); ?></strong>
                        </div>

                        <div>
                            <small>Adopted</small>
                            <strong><?php echo date("F j, Y", strtotime($my_pet['updated_at'])); ?></strong>
                        </div>

                    </div>

                    <a href="pet_tracker.php?id=<?php echo (int)$my_pet['id']; ?>" class="tracker-button">
                        View Pet Tracker →
                    </a>

                </div>

            <?php else: ?>

                <div class="tracker-photo emoji dog">🏡</div>

                <div class="tracker-info">

                    <span>🏡 YOUR PET</span>

                    <h2>No adopted pet yet</h2>

                    <p>Once a request is approved, your pet will show up here.</p>

                    <div class="tracker-details"></div>

                    <a href="browse_pets.php" class="tracker-button">
                        Browse Pets →
                    </a>

                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

</body>
</html>
