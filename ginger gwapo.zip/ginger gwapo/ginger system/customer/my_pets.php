<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

$stmt = mysqli_prepare($con, "SELECT p.id, p.name, p.species, p.breed, p.age, p.health_status, r.updated_at
                              FROM adoption_requests r
                              JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ? AND r.status = 'Approved'
                              ORDER BY r.updated_at DESC");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$my_pets = mysqli_stmt_get_result($stmt);

$page_kicker = "MY PETS";
$page_title  = "Your family 🏡";
$page_text   = "The pets you have welcomed home.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | My Pets</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "pets"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <section class="pets-section">

            <div class="pet-list">

                <?php if ($my_pets && mysqli_num_rows($my_pets) > 0): ?>
                    <?php while ($pet = mysqli_fetch_assoc($my_pets)): ?>
                        <?php list($cls, $emoji) = pet_look($pet['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

                            <div class="pet-info">

                                <span class="available">● <?php echo htmlspecialchars($pet['health_status']); ?></span>

                                <h3><?php echo htmlspecialchars($pet['name']); ?></h3>

                                <p>
                                    <?php echo htmlspecialchars($pet['breed']); ?> · <?php echo htmlspecialchars($pet['age']); ?><br>
                                    Adopted on <?php echo date("F j, Y", strtotime($pet['updated_at'])); ?>
                                </p>

                                <a href="pet_tracker.php?id=<?php echo (int)$pet['id']; ?>">View Pet Tracker →</a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div>🏡</div>
                        <h3>No adopted pets yet</h3>
                        <p>Once a request is approved, your new family member will show up here.</p>
                        <a href="browse_pets.php" class="btn">Browse pets</a>
                    </div>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

</body>
</html>
