<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

$pet_id = (int)($_GET['id'] ?? 0);

// Only show pets this adopter has actually adopted
$stmt = mysqli_prepare($con, "SELECT p.*, r.updated_at AS adopted_on
                              FROM adoption_requests r
                              JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ? AND r.pet_id = ? AND r.status = 'Approved'
                              LIMIT 1");
mysqli_stmt_bind_param($stmt, "si", $uid, $pet_id);
mysqli_stmt_execute($stmt);
$pet = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$pet)
{
    header("Location: my_pets.php");
    die;
}

list($cls, $emoji) = pet_look($pet['species']);

$page_kicker = "PET TRACKER";
$page_title  = htmlspecialchars($pet['name']);
$page_text   = "Everything about your pet in one place.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | <?php echo htmlspecialchars($pet['name']); ?></title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "pets"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <a href="my_pets.php" class="back-link">← Back to My Pets</a>

        <section class="detail">

            <div class="detail-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

            <div class="detail-info">

                <span class="badge approved">Adopted</span>

                <h2><?php echo htmlspecialchars($pet['name']); ?></h2>

                <div class="tracker-details">
                    <div>
                        <small>Breed</small>
                        <strong><?php echo htmlspecialchars($pet['breed']); ?></strong>
                    </div>
                    <div>
                        <small>Age</small>
                        <strong><?php echo htmlspecialchars($pet['age']); ?></strong>
                    </div>
                    <div>
                        <small>Gender</small>
                        <strong><?php echo htmlspecialchars($pet['gender']); ?></strong>
                    </div>
                    <div>
                        <small>Health</small>
                        <strong><?php echo htmlspecialchars($pet['health_status']); ?></strong>
                    </div>
                    <div>
                        <small>Adopted</small>
                        <strong><?php echo date("F j, Y", strtotime($pet['adopted_on'])); ?></strong>
                    </div>
                </div>

                <?php if (!empty($pet['description'])): ?>
                    <p class="detail-text"><?php echo nl2br(htmlspecialchars($pet['description'])); ?></p>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

</body>
</html>
