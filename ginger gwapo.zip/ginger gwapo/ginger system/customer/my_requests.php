<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];
$user_name = htmlspecialchars($user_data['user_name']);

// Cancel a pending request
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['cancel_id']))
{
    $request_id = (int)$_POST['cancel_id'];

    mysqli_begin_transaction($con);

    $stmt = mysqli_prepare($con, "SELECT pet_id FROM adoption_requests WHERE id = ? AND user_id = ? AND status = 'Pending' LIMIT 1");
    mysqli_stmt_bind_param($stmt, "is", $request_id, $uid);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row)
    {
        $stmt = mysqli_prepare($con, "DELETE FROM adoption_requests WHERE id = ? AND user_id = ? AND status = 'Pending'");
        mysqli_stmt_bind_param($stmt, "is", $request_id, $uid);
        mysqli_stmt_execute($stmt);

        // Put the pet back on the shelf
        $stmt = mysqli_prepare($con, "UPDATE pets SET status = 'Available' WHERE id = ? AND status = 'Pending'");
        mysqli_stmt_bind_param($stmt, "i", $row['pet_id']);
        mysqli_stmt_execute($stmt);

        mysqli_commit($con);
        header("Location: my_requests.php?cancelled=1");
        die;
    }

    mysqli_rollback($con);
    header("Location: my_requests.php");
    die;
}

$stmt = mysqli_prepare($con, "SELECT r.id, r.message, r.status, r.created_at,
                                     p.id AS pet_id, p.name, p.species, p.breed, p.age
                              FROM adoption_requests r
                              JOIN pets p ON p.id = r.pet_id
                              WHERE r.user_id = ?
                              ORDER BY r.created_at DESC, r.id DESC");
mysqli_stmt_bind_param($stmt, "s", $uid);
mysqli_stmt_execute($stmt);
$requests = mysqli_stmt_get_result($stmt);

$status_text = [
    "Pending"  => "Waiting for approval",
    "Approved" => "Approved. Welcome home!",
    "Rejected" => "Not approved this time",
];

$page_kicker = "MY REQUESTS";
$page_title  = "Your adoption requests 💌";
$page_text   = "Keep track of every pet you have asked to adopt.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | My Requests</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "requests"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if (isset($_GET['sent'])): ?>
            <p class="alert alert-success" role="status">Request sent! We'll let you know once it is reviewed.</p>
        <?php elseif (isset($_GET['cancelled'])): ?>
            <p class="alert alert-success" role="status">Request cancelled.</p>
        <?php endif; ?>

        <section class="request-list">

            <?php if ($requests && mysqli_num_rows($requests) > 0): ?>
                <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                    <?php list($cls, $emoji) = pet_look($r['species']); ?>

                    <article class="request-card">

                        <div class="request-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

                        <div class="request-info">

                            <h3>
                                <a href="pet_details.php?id=<?php echo (int)$r['pet_id']; ?>"><?php echo htmlspecialchars($r['name']); ?></a>
                            </h3>

                            <p><?php echo htmlspecialchars($r['breed']); ?> · <?php echo htmlspecialchars($r['age']); ?></p>
                            <small>Sent on <?php echo date("F j, Y", strtotime($r['created_at'])); ?></small>

                            <?php if (!empty($r['message'])): ?>
                                <p class="request-message">"<?php echo htmlspecialchars($r['message']); ?>"</p>
                            <?php endif; ?>

                        </div>

                        <div class="request-status">

                            <span class="badge <?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            <small><?php echo $status_text[$r['status']] ?? ""; ?></small>

                            <?php if ($r['status'] == "Pending"): ?>
                                <form method="post" onsubmit="return confirm('Cancel this request?');">
                                    <input type="hidden" name="cancel_id" value="<?php echo (int)$r['id']; ?>">
                                    <button type="submit" class="btn btn-soft">Cancel request</button>
                                </form>
                            <?php elseif ($r['status'] == "Approved"): ?>
                                <a href="pet_tracker.php?id=<?php echo (int)$r['pet_id']; ?>" class="btn">View my pet</a>
                            <?php endif; ?>

                        </div>

                    </article>

                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <div>💌</div>
                    <h3>No requests yet</h3>
                    <p>Find a pet you love and send your first adoption request.</p>
                    <a href="browse_pets.php" class="btn">Browse pets</a>
                </div>
            <?php endif; ?>

        </section>

    </main>

</div>

</body>
</html>
