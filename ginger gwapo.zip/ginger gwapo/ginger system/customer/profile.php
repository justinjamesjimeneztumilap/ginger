<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$uid       = $user_data['user_id'];

$success = "";
$error   = "";

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $action = $_POST['action'] ?? "";

    // Update email
    if ($action == "email")
    {
        $email = trim($_POST['email'] ?? "");

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100)
        {
            $error = "Please enter a valid email address.";
        }
        else
        {
            $stmt = mysqli_prepare($con, "SELECT id FROM users WHERE email = ? AND user_id <> ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, "ss", $email, $uid);
            mysqli_stmt_execute($stmt);

            if (mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)))
            {
                $error = "That email is already used by another account.";
            }
            else
            {
                $stmt = mysqli_prepare($con, "UPDATE users SET email = ? WHERE user_id = ?");
                mysqli_stmt_bind_param($stmt, "ss", $email, $uid);
                mysqli_stmt_execute($stmt);
                $success = "Email updated.";
            }
        }
    }

    // Change password
    if ($action == "password")
    {
        $current = $_POST['current_password'] ?? "";
        $new     = $_POST['new_password'] ?? "";
        $confirm = $_POST['confirm_password'] ?? "";

        if (!password_verify($current, $user_data['password']))
        {
            $error = "Your current password is incorrect.";
        }
        elseif (strlen($new) < 6)
        {
            $error = "Your new password must be at least 6 characters.";
        }
        elseif ($new !== $confirm)
        {
            $error = "The new passwords don't match.";
        }
        else
        {
            $hash = password_hash($new, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($con, "UPDATE users SET password = ? WHERE user_id = ?");
            mysqli_stmt_bind_param($stmt, "ss", $hash, $uid);
            mysqli_stmt_execute($stmt);
            $success = "Password changed.";
        }
    }

    // Reload the latest account data
    $user_data = check_login($con);
}

$user_name = htmlspecialchars($user_data['user_name']);

$page_kicker = "PROFILE";
$page_title  = "Your account 👤";
$page_text   = "Manage your email and password.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Profile</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "profile"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <?php if ($success !== ""): ?>
            <p class="alert alert-success" role="status"><?php echo htmlspecialchars($success); ?></p>
        <?php endif; ?>

        <?php if ($error !== ""): ?>
            <p class="alert alert-error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <section class="profile-grid">

            <article class="form-card">

                <h2>Account details</h2>

                <div class="tracker-details">
                    <div>
                        <small>Username</small>
                        <strong><?php echo $user_name; ?></strong>
                    </div>
                    <div>
                        <small>Member since</small>
                        <strong><?php echo date("F j, Y", strtotime($user_data['date'])); ?></strong>
                    </div>
                </div>

                <form method="post">

                    <input type="hidden" name="action" value="email">

                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>

                    <button type="submit" class="btn">Save email</button>

                </form>

            </article>

            <article class="form-card">

                <h2>Change password</h2>

                <form method="post">

                    <input type="hidden" name="action" value="password">

                    <label for="current_password">Current password</label>
                    <input type="password" id="current_password" name="current_password" required>

                    <label for="new_password">New password</label>
                    <input type="password" id="new_password" name="new_password" minlength="6" required>

                    <label for="confirm_password">Confirm new password</label>
                    <input type="password" id="confirm_password" name="confirm_password" minlength="6" required>

                    <button type="submit" class="btn">Change password</button>

                </form>

            </article>

        </section>

    </main>

</div>

</body>
</html>
