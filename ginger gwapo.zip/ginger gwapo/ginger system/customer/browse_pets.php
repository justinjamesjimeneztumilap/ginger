<?php
session_start();

include("../connection.php");
include("../functions.php");

$user_data = require_role($con, "Adopter");
$user_name = htmlspecialchars($user_data['user_name']);

// Search + filter
$q       = trim($_GET['q'] ?? "");
$species = $_GET['species'] ?? "";
if (!in_array($species, ["Dog", "Cat", "Other"], true)) { $species = ""; }

$sql    = "SELECT id, name, species, breed, age, gender FROM pets WHERE status = 'Available'";
$types  = "";
$params = [];

if ($species !== "")
{
    $sql .= " AND species = ?";
    $types .= "s";
    $params[] = $species;
}

if ($q !== "")
{
    $sql .= " AND (name LIKE ? OR breed LIKE ?)";
    $types .= "ss";
    $like = "%" . $q . "%";
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY created_at DESC, id DESC";

$stmt = mysqli_prepare($con, $sql);
if ($types !== "") { mysqli_stmt_bind_param($stmt, $types, ...$params); }
mysqli_stmt_execute($stmt);
$pets = mysqli_stmt_get_result($stmt);

$page_kicker = "BROWSE PETS";
$page_title  = "Meet your new best friend 🐾";
$page_text   = "Every pet here is ready for a loving home.";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PetAdopt | Browse Pets</title>

    <link rel="stylesheet" href="../style/adopter_dashboard.css">
</head>

<body>

<div class="dashboard">

    <?php $active = "browse"; include("sidebar.php"); ?>

    <main class="main-content">

        <?php include("topbar.php"); ?>

        <form method="get" class="filters">

            <input type="text" name="q" placeholder="Search by name or breed" value="<?php echo htmlspecialchars($q); ?>">

            <select name="species">
                <option value="">All pets</option>
                <option value="Dog"   <?php echo $species == "Dog"   ? "selected" : ""; ?>>Dogs</option>
                <option value="Cat"   <?php echo $species == "Cat"   ? "selected" : ""; ?>>Cats</option>
                <option value="Other" <?php echo $species == "Other" ? "selected" : ""; ?>>Other</option>
            </select>

            <button type="submit" class="btn">Search</button>

            <?php if ($q !== "" || $species !== ""): ?>
                <a href="browse_pets.php" class="btn btn-soft">Clear</a>
            <?php endif; ?>

        </form>

        <section class="pets-section">

            <div class="pet-list">

                <?php if ($pets && mysqli_num_rows($pets) > 0): ?>
                    <?php while ($pet = mysqli_fetch_assoc($pets)): ?>
                        <?php list($cls, $emoji) = pet_look($pet['species']); ?>

                        <article class="pet-card">

                            <div class="pet-photo emoji <?php echo $cls; ?>"><?php echo $emoji; ?></div>

                            <div class="pet-info">

                                <span class="available">● Available</span>

                                <h3><?php echo htmlspecialchars($pet['name']); ?></h3>

                                <p>
                                    <?php echo htmlspecialchars($pet['breed']); ?> · <?php echo htmlspecialchars($pet['age']); ?> · <?php echo htmlspecialchars($pet['gender']); ?>
                                </p>

                                <a href="pet_details.php?id=<?php echo (int)$pet['id']; ?>">View Pet →</a>

                            </div>

                        </article>

                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div>🔎</div>
                        <h3>No pets found</h3>
                        <p>Try a different name or breed, or clear the filters.</p>
                    </div>
                <?php endif; ?>

            </div>

        </section>

    </main>

</div>

</body>
</html>
