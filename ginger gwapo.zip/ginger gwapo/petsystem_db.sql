-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2026 at 09:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petsystem_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoption_requests`
--

CREATE TABLE `adoption_requests` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption_requests`
--

INSERT INTO `adoption_requests` (`id`, `user_id`, `pet_id`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1, 7699410573718581, 1, 'I have a big yard and would love to give Buddy a home.', 'Approved', '2026-10-01 18:41:11', '2026-10-01 19:06:05'),
(3, 138756443764893810, 5, '213', 'Approved', '2026-10-01 19:06:52', '2026-10-01 19:09:33');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `species` enum('Dog','Cat','Other') NOT NULL DEFAULT 'Dog',
  `breed` varchar(100) NOT NULL,
  `age` varchar(30) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `description` text DEFAULT NULL,
  `health_status` varchar(50) NOT NULL DEFAULT 'Healthy',
  `status` enum('Available','Pending','Adopted') NOT NULL DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id`, `name`, `species`, `breed`, `age`, `gender`, `description`, `health_status`, `status`, `created_at`) VALUES
(1, 'Buddy', 'Dog', 'Golden Retriever', '2 years', 'Male', 'Friendly, loves fetch and long walks.', 'Healthy', 'Adopted', '2026-10-01 18:41:11'),
(2, 'Luna', 'Cat', 'Domestic Shorthair', '1 year', 'Female', 'Calm and cuddly, great with kids.', 'Healthy', 'Available', '2026-10-01 18:41:11'),
(3, 'Milo', 'Dog', 'Shih Tzu', '3 years', 'Male', 'Gentle lap dog who enjoys quiet evenings.', 'Healthy', 'Available', '2026-10-01 18:41:11'),
(4, 'Bella', 'Dog', 'Labrador Mix', '4 years', 'Female', 'Playful, house-trained and good with other dogs.', 'Healthy', 'Available', '2026-10-01 18:41:11'),
(5, 'Oliver', 'Cat', 'Orange Tabby', '2 years', 'Male', 'Curious explorer who loves window seats.', 'Healthy', 'Adopted', '2026-10-01 18:41:11'),
(6, 'Coco', 'Dog', 'Beagle', '1 year', 'Female', 'Energetic and sweet, needs an active family.', 'Healthy', 'Available', '2026-10-01 18:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `security_question` varchar(100) NOT NULL,
  `security_answer` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_type` enum('Admin','Adopter') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `email`, `password`, `security_question`, `security_answer`, `date`, `user_type`) VALUES
(4, 138756443764893810, 'Justin@Justin1', 'Justin@Justin1', '$2y$10$tTpm8Q3BIc4G0DnXFgAE8Ov3uNDv6i1Fk6.60DiRbK6bggi6QIa0O', 'What is your favorite color?', 'Justin@Justin1', '2026-10-01 18:43:48', 'Adopter'),
(55555, 5555, 'admin@petadopt.com22', 'admin@petadopt.com22', '$2y$10$5dpBXtw9G0u27qWlQlJMsu3sBE6e4o2u0Mtjpn4qoWcofkeQVoF0m', 'admin@petadopt.com22', 'admin@petadopt.com22', '2026-10-20 19:07:14', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `pet_id` (`pet_id`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `date` (`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55556;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adoption_requests`
--
ALTER TABLE `adoption_requests`
  ADD CONSTRAINT `fk_request_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
